window.onload = () => {
    fetch('./todos')
        .then(response => response.json())
        .then(data => {
        const todos = data;
        let help = data;
        todos.forEach(t => console.log(`Todo: ${t.name} - ${t.description}`));
        // @ts-ignore
        let table = document.querySelector("#table");
        table.innerHTML = `<tr>
<th>Name</th>
<th>Description></th>
</tr>`;
        for (let i = 0; i < todos.length; i++) {
            table.innerHTML += `<tr>
<td>${todos[i].name}</td>
<td>${todos[i].description}</td>
</tr>`;
        }
    });
};
export {};
// 23

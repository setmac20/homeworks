import {response} from "express";
import {ITodo} from "../../model/ITodo";

window.onload = () => {
    fetch('./todos')
        .then(response => response.json())
        .then(data => {
            const todos: ITodo[] = data as ITodo[];
            let help: ITodo[] = data;
            todos.forEach(t => console.log(`Todo: ${t.name} - ${t.description}`))

            // @ts-ignore
            let table: HTMLTableElement = document.querySelector("#table");
            table.innerHTML = `<tr>
<th>Name</th>
<th>Description></th>
</tr>`
            for (let i = 0; i < todos.length; i++) {
                table.innerHTML += `<tr>
<td>${todos[i].name}</td>
<td>${todos[i].description}</td>
</tr>`
            }
        });

}

// 23
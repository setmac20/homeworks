import express,{Request, Response} from "express";
import {ITodo} from "../model/ITodo";

let router = express.Router();
let todos:ITodo[] = [
    {
        name:"Test", description:"some text"
    },
    {
        name:"Have fun", description:"Enjoy my holidays!"
    }
]
router.get('/', (req: Request, res: Response) => {
    res.send(todos)
});
// 18999
module.exports = router;